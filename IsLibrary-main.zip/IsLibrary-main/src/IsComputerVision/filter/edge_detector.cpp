#include <IsComputerVision/filter/utils/utils_filter.hpp>
#include <IsComputerVision/filter/edge_detector.hpp>


namespace is
{
    namespace imgproc
    {
        using namespace nbla;

        NdArrayPtr sobelFilter(NdArrayPtr src, int direction)
        {
            IS_CHECK_NDARRAY_SHAPE_AS_IMAGE(src);
            IS_DEBUG_CHECK_NDARRAY_STATE(IS_DEBUG_FLAG, src);

            const auto &ctx = SingletonManager::get<GlobalContext>()->get_current_context();
            auto sh = src->shape();
            auto st = src->strides();

            // 微分カーネル
            int ksize_x = 3;
            int ksize_y = 3;
            int kernel_size = ksize_x * ksize_y;
            double *p_kernel = new double[kernel_size];
            IS_ZERO_MEMORY(p_kernel, sizeof(double) * kernel_size);
            int hlf_ksx = (int)(ksize_x / 2);
            int hlf_ksy = (int)(ksize_y / 2);

            // パディング
            auto extend = padding<double>(src, hlf_ksx, hlf_ksy, IS_PADDING_MEAN);

            // 演算結果
            auto dst = zeros<double>(sh);

            // 微分方向 8つ
            direction = direction % 7;

            // →
            if (direction == 0)
            {
                p_kernel[0] = -1;  p_kernel[1] = 0;  p_kernel[2] = 1;
                p_kernel[3] = -2;  p_kernel[4] = 0;  p_kernel[5] = 2;
                p_kernel[6] = -1;  p_kernel[7] = 0;  p_kernel[8] = 1;
            }
            // → ↓
            else if (direction == 1)
            {
                p_kernel[0] = -2;  p_kernel[1] = -1; p_kernel[2] = 0;
                p_kernel[3] = -1;  p_kernel[4] = 0;  p_kernel[5] = 1;
                p_kernel[6] = 0;   p_kernel[7] = 1;  p_kernel[8] = 2;
            }
            // ↓
            else if (direction == 2)
            {
                p_kernel[0] = -1; p_kernel[1] = -2; p_kernel[2] = -1;
                p_kernel[3] = 0;  p_kernel[4] = 0;  p_kernel[5] = 0;
                p_kernel[6] = 1;  p_kernel[7] = 2;  p_kernel[8] = 1;
            }
            // ← ↓
            else if (direction == 3)
            {
                p_kernel[0] = 0;  p_kernel[1] = -1; p_kernel[2] = -2;
                p_kernel[3] = 1;  p_kernel[4] = 0;  p_kernel[5] = -1;
                p_kernel[6] = 2;  p_kernel[7] = 1;  p_kernel[8] = 0;
            }
            // ←
            else if (direction == 4)
            {
                p_kernel[0] = 1; p_kernel[1] = 0; p_kernel[2] = -1;
                p_kernel[3] = 2; p_kernel[4] = 0; p_kernel[5] = -2;
                p_kernel[6] = 1; p_kernel[7] = 0; p_kernel[8] = -1;
            }
            // ← ↑
            else if (direction == 5)
            {
                p_kernel[0] = 2; p_kernel[1] = 1;  p_kernel[2] = 0;
                p_kernel[3] = 1; p_kernel[4] = 0;  p_kernel[5] = -1;
                p_kernel[6] = 0; p_kernel[7] = -1; p_kernel[8] = -2;
            }
            // ↑
            else if (direction == 6)
            {
                p_kernel[0] = 1;  p_kernel[1] = 2;  p_kernel[2] = 1;
                p_kernel[3] = 0;  p_kernel[4] = 0;  p_kernel[5] = 0;
                p_kernel[6] = -1; p_kernel[7] = -2; p_kernel[8] = -1;
            }
            // → ↑
            else 
            { // 7
                p_kernel[0] = 0;  p_kernel[1] = 1;  p_kernel[2] = 2;
                p_kernel[3] = -1; p_kernel[4] = 0;  p_kernel[5] = 1;
                p_kernel[6] = -2; p_kernel[7] = -1; p_kernel[8] = 0;
            }

            // 畳み込み演算
            convolution<double>(dst, extend, Size(ksize_x, ksize_y), p_kernel);

            delete[] p_kernel;

            return dst;
        }


        NdArrayPtr laplacianFilter(NdArrayPtr src, bool is_elem_8) {
            IS_CHECK_NDARRAY_SHAPE_AS_IMAGE(src);
            IS_DEBUG_CHECK_NDARRAY_STATE(IS_DEBUG_FLAG, src);

            const auto &ctx =
                SingletonManager::get<GlobalContext>()->get_current_context();
            auto sh = src->shape();
            auto st = src->strides();

            // Laplacianカーネル
            int ksize_x = 3;
            int ksize_y = 3;
            int kernel_size = ksize_x * ksize_y;
            double *p_kernel = new double[kernel_size];
            IS_ZERO_MEMORY(p_kernel, sizeof(double) * kernel_size);
            int hlf_ksx = (int)(ksize_x / 2);
            int hlf_ksy = (int)(ksize_y / 2);

            if (is_elem_8) {
              p_kernel[0] = 1; p_kernel[1] = 1;  p_kernel[2] = 1;
              p_kernel[3] = 1; p_kernel[4] = -8; p_kernel[5] = 1;
              p_kernel[6] = 1; p_kernel[7] = 1;  p_kernel[8] = 1;
            }
            else {
              p_kernel[0] = 0; p_kernel[1] = 1;  p_kernel[2] = 0;
              p_kernel[3] = 1; p_kernel[4] = -4; p_kernel[5] = 1;
              p_kernel[6] = 0; p_kernel[7] = 1;  p_kernel[8] = 0;
            }

            // パディング
            auto extend = padding<double>(src, hlf_ksx, hlf_ksy, IS_PADDING_MEAN);

            // 演算結果
            auto dst = zeros<double>(sh);

            // 畳み込み演算
            convolution<double>(dst, extend, Size(ksize_x, ksize_y), p_kernel);

            delete[] p_kernel;

            return dst;
        }

        NdArrayPtr logFilter(NdArrayPtr src, double sigma) {
            IS_CHECK_NDARRAY_SHAPE_AS_IMAGE(src);
            IS_DEBUG_CHECK_NDARRAY_STATE(IS_DEBUG_FLAG, src);

            const auto &ctx =
                SingletonManager::get<GlobalContext>()->get_current_context();
            auto sh = src->shape();
            auto st = src->strides();

            // LoGカーネル
            int ksize = 3;
            int kernel_size = ksize * ksize;
            double *p_kernel = new double[kernel_size];
            IS_ZERO_MEMORY(p_kernel, sizeof(double) * kernel_size);
            int hlf_ks = (int)(ksize / 2);

            // http://opencv.jp/opencv-2.1/cpp/image_filtering.html#getGaussianKernel
            sigma = (sigma != 0) ? sigma : 0.3 * (ksize / 2 - 1) + 0.8;
            IS_DEBUG_STREAM("sigma: %.3f\n", sigma);

            int dx, dy;
            double norm, sig2, coef, dist, val;
            double sum = 0;
            sig2 = sigma * sigma;
            
            for (int j = 0; j < ksize; ++j) {
                for (int i = 0; i < ksize; ++i) {
                    dy = j - hlf_ks;
                    dx = i - hlf_ks;
                    norm = dx *dx + dy *dy;
                    coef = norm - sig2;
                    dist = -0.5 * norm / (2 * sig2);
                    val = coef * std::exp(dist);
                    p_kernel[j * ksize + i] = val;
                    sum += val;
                }
            }
            
            // 正規化
            for (int k = 0; k < kernel_size; ++k) {
                p_kernel[k] /= sum;
            }

            // パディング
            auto extend = padding<double>(src, hlf_ks, hlf_ks, IS_PADDING_MEAN);

            // 演算結果
            auto dst = zeros<double>(sh);

            // 畳み込み演算
            convolution<double>(dst, extend, Size(ksize, ksize), p_kernel);

            delete[] p_kernel;

            return dst;
        }
    } // imgproc
}