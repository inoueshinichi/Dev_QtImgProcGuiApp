#include <IsNdArray/event.hpp>

namespace is
{
    namespace nbla
    {
        Event::~Event() {}
    }
}