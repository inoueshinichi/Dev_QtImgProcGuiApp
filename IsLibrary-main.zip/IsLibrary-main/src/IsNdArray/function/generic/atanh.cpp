#include <IsNdArray/function/atanh.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(ATanh)
    }
}