#include <IsNdArray/function/pow_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(PowScalar, double, bool)
    }
}