#include <IsNdArray/function/acos.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(ACos)
    }
}