#include <IsNdArray/function/greater_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(GreaterScalar, double)
    }
}