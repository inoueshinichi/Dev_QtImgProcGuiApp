#include <IsNdArray/function/logical_not.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(LogicalNot)
    }
}