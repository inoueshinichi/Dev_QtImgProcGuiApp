#include <IsNdArray/function/asin.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(ASin)
    }
}