#include <IsNdArray/function/abs.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Abs)
    }
}