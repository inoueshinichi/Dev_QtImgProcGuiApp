#include <IsNdArray/function/floor.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Floor)
    }
}