#include <IsNdArray/function/minimum_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(MinimumScalar, double)
    }
}