#include <IsNdArray/function/sub2.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Sub2, bool)
    }
}