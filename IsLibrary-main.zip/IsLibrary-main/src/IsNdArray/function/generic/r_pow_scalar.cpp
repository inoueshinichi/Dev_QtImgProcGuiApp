#include <IsNdArray/function/r_pow_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(RPowScalar, double)
    }
}