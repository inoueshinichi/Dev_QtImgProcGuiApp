#include <IsNdArray/function/log10.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Log10)
    }
}