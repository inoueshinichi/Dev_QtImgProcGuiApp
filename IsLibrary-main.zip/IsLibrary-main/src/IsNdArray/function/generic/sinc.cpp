#include <IsNdArray/function/sinc.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Sinc)
    }
}