#include <IsNdArray/function/sqrt.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Sqrt)
    }
}