#include <IsNdArray/function/bc_add2.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(BcAdd2, bool)
    }
}