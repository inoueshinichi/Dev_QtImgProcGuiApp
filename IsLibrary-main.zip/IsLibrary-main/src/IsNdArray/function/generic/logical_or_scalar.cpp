#include <IsNdArray/function/logical_or_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(LogicalOrScalar, bool)
    }
}