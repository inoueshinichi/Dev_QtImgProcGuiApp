#include <IsNdArray/function/logical_xor_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(LogicalXorScalar, bool)
    }
}