#include <IsNdArray/function/sin.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Sin)
    }
}