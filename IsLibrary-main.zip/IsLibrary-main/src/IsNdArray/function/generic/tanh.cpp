#include <IsNdArray/function/tanh.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Tanh)
    }
}