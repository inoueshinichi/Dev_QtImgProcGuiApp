#include <IsNdArray/function/tan.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Tan)
    }
}