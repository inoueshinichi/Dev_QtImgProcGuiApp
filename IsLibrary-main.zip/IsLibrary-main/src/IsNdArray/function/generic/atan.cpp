#include <IsNdArray/function/atan.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(ATan)
    }
}