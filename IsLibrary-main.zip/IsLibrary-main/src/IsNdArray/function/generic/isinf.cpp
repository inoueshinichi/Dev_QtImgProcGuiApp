#include <IsNdArray/function/isinf.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(IsInf)
    }
}