#include <IsNdArray/function/logical_and_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(LogicalAndScalar, bool)
    }
}