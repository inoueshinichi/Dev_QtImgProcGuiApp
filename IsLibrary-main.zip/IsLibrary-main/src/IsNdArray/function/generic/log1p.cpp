#include <IsNdArray/function/log1p.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Log1p)
    }
}