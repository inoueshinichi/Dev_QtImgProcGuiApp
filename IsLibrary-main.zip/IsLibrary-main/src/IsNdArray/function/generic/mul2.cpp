#include <IsNdArray/function/mul2.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Mul2, bool)
    }
}