#include <IsNdArray/function/less_equal.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(LessEqual)
    }
}