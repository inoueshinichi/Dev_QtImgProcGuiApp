#include <IsNdArray/function/less_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(LessScalar, double)
    }
}