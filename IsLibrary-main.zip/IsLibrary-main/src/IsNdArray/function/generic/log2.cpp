#include <IsNdArray/function/log2.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Log2)
    }
}