#include <IsNdArray/function/maximum2.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Maximum2)
    }
}