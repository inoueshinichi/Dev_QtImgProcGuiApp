#include <IsNdArray/function/logical_or.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(LogicalOr)
    }
}