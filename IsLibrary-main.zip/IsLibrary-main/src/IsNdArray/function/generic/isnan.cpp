#include <IsNdArray/function/isnan.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(IsNan)
    }
}