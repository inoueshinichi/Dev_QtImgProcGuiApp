#include <IsNdArray/function/equal_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(EqualScalar, double)
    }
}