#include <IsNdArray/function/pow2.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Pow2)
    }
}