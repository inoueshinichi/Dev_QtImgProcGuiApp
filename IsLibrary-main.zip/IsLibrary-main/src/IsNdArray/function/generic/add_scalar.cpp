#include <IsNdArray/function/add_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(AddScalar, double, bool)
    }
}