#include <IsNdArray/function/atan2.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(ATan2)
    }
}