#include <IsNdArray/function/cosh.hpp>


namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Cosh)
    }
}