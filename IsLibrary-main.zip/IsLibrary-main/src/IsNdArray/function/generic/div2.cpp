#include <IsNdArray/function/div2.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(Div2, bool)
    }
}