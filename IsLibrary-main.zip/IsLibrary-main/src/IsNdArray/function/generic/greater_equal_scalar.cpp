#include <IsNdArray/function/greater_equal_scalar.hpp>

namespace is
{
    namespace nbla
    {
        NBLA_REGISTER_FUNCTION_SOURCE(GreaterEqualScalar, double)
    }
}